<?php

return [
    'publicKey' => getPaymentEnv('FLW_PUBLIC_KEY'),

    'secretKey' => getPaymentEnv('FLW_SECRET_KEY'),

    'secretHash' => getPaymentEnv('FLW_SECRET_HASH'),
];
