<?php
return [
    'key' => getPaymentEnv('MOLLIE_SECRET_KEY'),
];
