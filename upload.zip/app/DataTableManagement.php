<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DataTableManagement extends Model
{
    protected $guarded = ['id'];
}
